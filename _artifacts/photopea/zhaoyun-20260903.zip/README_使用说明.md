# 赵云：Photopea MCP 拆层与 Spine 初始绑定

原图：`../zhaoyun.png`，498 × 345，RGBA 透明背景。

这是一套已经跑通的小幅动作绑定底稿。切图、关节补绘、枪杆补全、图层合并和 PSD 保存均通过本地 Photopea MCP 执行。原图文件未修改。

## 使用文件

- `zhaoyun-spine.psd`：29 个可见部件，另有 1 个隐藏原图参考层。
- `zhaoyun-spine.json` + `images/`：Spine 4.2 格式初始骨架，30 根骨骼、29 个插槽、2 条双臂 IK 约束。
- `离线预览.html`：双击即可打开，无需服务或联网。提供待机、关节检查、骨骼显示、独立武器和展开部件视图。
- `zhaoyun-rig-check.gif`：由官方 Spine 运行库实际渲染的动作预览。
- `zhaoyun-parts-preview.png`：各部件与补绘连接区总览。
- `zhaoyun-bones-preview.png`：初始骨骼位置。
- `parts-manifest.json`：裁切边界、透明留边、原图坐标中的关节位置。

## 在 Spine 中使用

推荐导入附带的 JSON，可直接获得已经设置好的骨骼、插槽、双手持枪约束和两段检查动画。

1. 解压完整文件夹，保持 JSON 与 `images/` 的相对位置。
2. 在 Spine 4.2 中使用主菜单 **Import Data / 导入数据**，选择 `zhaoyun-spine.json`，缩放设为 1。
3. 如果图像未显示，把图像路径设置到本文件夹的 `images/`。
4. 在动画模式切换 `idle` 和 `rig_check`。完成检查后另存为自己的 `.spine` 项目。
5. `weapon` 是武器总控。两只手是其子骨骼，双臂 IK 以手腕为目标。移动或小幅旋转 `weapon`，双臂随握点移动。

JSON 使用 4.2.43 格式标识，验证用官方 `@esotericsoftware/spine-canvas` 4.2.120。更高版本编辑器的升级导入未实际测试。

也可以使用 **Import PSD / 导入 PSD** 导入 `zhaoyun-spine.psd` 重新绑定；这种方式只导入图层，不会自动得到随附 JSON 中的精确关节与 IK。参考层名为 `source_reference [ignore]`，应保持隐藏并忽略。各层已经是普通像素层，无需应用图层效果。

官方文档：[导入 PSD](https://esotericsoftware.com/spine-import-psd)、[JSON 格式与导入](https://esotericsoftware.com/spine-json-format)。

## 部件划分

命名中的 L / R 指画面左 / 右。

| 部位 | 图层 |
| --- | --- |
| 头与饰物 | head、helmet_plume |
| 身体与披风 | torso、pelvis、cape |
| 左右手臂 | shoulder、upperarm、forearm、hand，各 L / R |
| 左右腿 | thigh、knee、shin、foot，各 L / R |
| 裙甲 | tasset、skirt，各 L / R；tabard |
| 独立武器 | spear_shaft、spear_head、spear_tassel |

双手与枪杆分开，枪杆被双手遮住的两段已补齐。披风、躯干、腰部和主要肢体加入了被前景遮住的连接区域。PNG 附件保留 2 像素透明留边；所有位置均由 PSD 原始画布坐标换算，无需手动重新对齐。

## 实际验证结果

- PSD 共 30 层，29 个可见部件；所有附件均有非空透明 PNG。
- 初始叠合透明通道变化：0 像素。
- 初始叠合预乘 RGB 平均绝对误差：0。
- 官方运行库初始渲染与原图放大两倍后的预乘 RGB 平均绝对误差：0。
- 在初始姿势、`idle`、`rig_check` 中检查共 183 个姿势，未出现运行库错误或无效骨骼变换。
- 双臂末端与握点最大计算误差约 0.000004 像素。
- 补全后的枪杆为一个连通部件；披风和主要上下肢连接区也已连通。

这里验证了 PSD 解析、官方运行库加载与实际渲染，没有在 Spine 桌面编辑器中完成界面导入验收。

## 后续动画的边界

这是从一张已经合并的 PNG 拆出的当前视角底稿。隐藏部分采用局部金属/布料色调补绘，不是原作者提供的完整隐藏结构。当前绑定采用刚性区域附件，尚未制作加权网格、变形动画、换手皮肤、面部表情或多视角。

附带检查动画使用头部约 ±5°、腿部约 ±5°、武器约 ±2° 的小幅动作。大幅攻击、举枪、转身、深蹲时，可能露出补绘纹理与切口，需要针对目标动作继续完善关节遮挡、披风和腰甲网格权重。请先看部件总览和动作预览，再扩展动作幅度。

本地 `work/` 保留了可复现脚本、Photopea MCP 调用记录与验证报告；交付压缩包仅包含使用文件。离线预览包含官方 Spine 运行库，许可文本见 `Spine-Runtime-LICENSE.txt`。
