# 部件重组差异报告

本报告把 `16` 个 RGBA 部件按 `layers.json` 中的顺序（深度中位数由大到小，即从后向前）重组。
原图使用与 See-through 相同的居中正方形留边和双线性缩放后再比较。

| 指标 | 结果 |
|---|---:|
| Alpha 轮廓 IoU | 97.43% |
| Alpha 精确率 | 100.00% |
| Alpha 召回率 | 97.43% |
| 预乘 RGBA 平均绝对误差 | 1.66% |
| 灰底合成 RGB 平均绝对误差 | 2.16% |
| 灰底合成 PSNR | 22.46 dB |
| 交集区域 RGB 平均绝对误差 | 7.68% |
| 差异超过 10/255 的像素 | 14.04% |

`Alpha IoU` 反映整体轮廓覆盖；`预乘 RGBA MAE` 同时计入颜色与透明度。
这些是像素级诊断值，不应当解读为人眼感知质量或 Spine 可用率。

## 叠加顺序

topwear → legwear → footwear → back hair → face → mouth → irides-l → eyewhite-r → eyewhite-l → irides-r → eyelash-l → eyelash-r → handwear-r → front hair → handwear-l → objects
