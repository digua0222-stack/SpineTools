# 部件重组差异报告

本报告把 `26` 个 RGBA 部件按 `layers.json` 中的顺序（深度中位数由大到小，即从后向前）重组。
原图使用与 See-through 相同的居中正方形留边和双线性缩放后再比较。

| 指标 | 结果 |
|---|---:|
| Alpha 轮廓 IoU | 94.85% |
| Alpha 精确率 | 95.68% |
| Alpha 召回率 | 99.10% |
| 预乘 RGBA 平均绝对误差 | 1.06% |
| 灰底合成 RGB 平均绝对误差 | 1.08% |
| 灰底合成 PSNR | 24.42 dB |
| 交集区域 RGB 平均绝对误差 | 27.04% |
| 差异超过 10/255 的像素 | 4.28% |

`Alpha IoU` 反映整体轮廓覆盖；`预乘 RGBA MAE` 同时计入颜色与透明度。
这些是像素级诊断值，不应当解读为人眼感知质量或 Spine 可用率。

## 叠加顺序

handwear-l → footwear → ears-r → earwear → face → nose → handwear-r → neckwear → wings → ears-l → legwear → tail → neck → topwear → bottomwear → headwear → eyewear → front hair → eyelash-r → eyewhite-r → eyewhite-l → irides-r → irides-l → objects → eyelash-l → back hair
